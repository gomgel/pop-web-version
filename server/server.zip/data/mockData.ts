export interface Account {
  id: string;
  name: string;
  description: string;
  active: boolean;
  createdOn: string;
  createdBy: string;
  modifiedOn: string;
  modifiedBy: string;
  jobTitle: string;
  department: string;
  status: string;
  purchaseOrder?: string;
  expectedArrivalDate?: string;
  hiringDate?: string;
}

export const mockAccounts: Account[] = [
  {
    id: "1",
    name: "Default Roleaa",
    description: "Default role",
    active: true,
    createdOn: "2017-02-15T00:00:00",
    createdBy: "Super Admin",
    modifiedOn: "2017-02-15T00:00:00",
    modifiedBy: "Super Admin",
    jobTitle: "Designer",
    department: "HR",
    status: "Active",
    purchaseOrder: "PO-001",
    hiringDate: "2017-10-30",
    expectedArrivalDate: "2017-11-15",
  },
  {
    id: "2",
    name: "HR Specialists",
    description: "HR Role",
    active: true,
    createdOn: "2017-02-15T00:00:00",
    createdBy: "Super Admin",
    modifiedOn: "2017-02-15T00:00:00",
    modifiedBy: "Super Admin",
    jobTitle: "HR Specialist",
    department: "HR",
    status: "Active",
    purchaseOrder: "PO-002",
    hiringDate: "2017-11-01",
    expectedArrivalDate: "2017-11-20",
  },
  {
    id: "3",
    name: "Finance Specialist",
    description: "Finance Specialit role",
    active: true,
    createdOn: "2017-02-15T00:00:00",
    createdBy: "Super Admin",
    modifiedOn: "2017-02-15T00:00:00",
    modifiedBy: "Super Admin",
    jobTitle: "Finance Specialist",
    department: "Finance",
    status: "Inactive",
  },
  {
    id: "4",
    name: "Operations Specialist",
    description: "Operations Specialist role",
    active: true,
    createdOn: "2017-02-15T00:00:00",
    createdBy: "Super Admin",
    modifiedOn: "2017-02-15T00:00:00",
    modifiedBy: "Super Admin",
    jobTitle: "Operations Specialist",
    department: "Operations",
    status: "Active",
  },
  {
    id: "5",
    name: "Sales Specialist",
    description: "Sales Specialist role",
    active: true,
    createdOn: "2017-02-15T00:00:00",
    createdBy: "Super Admin",
    modifiedOn: "2017-02-15T00:00:00",
    modifiedBy: "Super Admin",
    jobTitle: "Sales Specialist",
    department: "Sales",
    status: "Inactive",
  },
  {
    id: "6",
    name: "Support Specialist",
    description: "Support Specialist role",
    active: true,
    createdOn: "2017-02-15T00:00:00",
    createdBy: "Super Admin",
    modifiedOn: "2017-02-15T00:00:00",
    modifiedBy: "Super Admin",
    jobTitle: "Support Specialist",
    department: "Support",
    status: "Active",
  },
  {
    id: "7",
    name: "Executive",
    description: "Executive role",
    active: true,
    createdOn: "2017-02-15T00:00:00",
    createdBy: "Super Admin",
    modifiedOn: "2017-02-15T00:00:00",
    modifiedBy: "Super Admin",
    jobTitle: "Executive",
    department: "Management",
    status: "Active",
  },
  {
    id: "8",
    name: "IT Specialist",
    description: "IT Specialist role",
    active: true,
    createdOn: "2017-02-15T00:00:00",
    createdBy: "Super Admin",
    modifiedOn: "2017-02-15T00:00:00",
    modifiedBy: "Super Admin",
    jobTitle: "IT Specialist",
    department: "IT",
    status: "Active",
  },
];
